DROP TABLE IF EXISTS `#__jaem_log`;
DROP TABLE IF EXISTS `#__jaem_services`;